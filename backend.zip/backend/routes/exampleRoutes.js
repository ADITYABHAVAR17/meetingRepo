const express = require("express");
const { getExampleData } = require("../controllers/exampleController");

const router = express.Router();

router.route("/example").get(getExampleData);

module.exports = router;
