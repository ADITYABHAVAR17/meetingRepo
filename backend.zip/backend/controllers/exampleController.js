exports.getExampleData = (req, res, next) => {
  res.status(200).json({
    success: true,
    message: "This is an example controller response.",
  });
};
